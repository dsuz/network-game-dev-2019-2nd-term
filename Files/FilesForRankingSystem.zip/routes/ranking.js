﻿'use strict';
var express = require('express');
var router = express.Router();

// データベース接続設定
const pg = require('pg');
const connectionString = process.env.DATABASE_URL;  // (プロジェクトプロパティの)環境変数からデータベース接続文字列を取得する
const pool = new pg.Pool({
    connectionString: connectionString
});

// GET リクエストを受け取った時の処理（データベースからランキングを取ってきて表示する）
router.get('/', function (req, res) {
    const q = 'SELECT name, score FROM ranking ORDER BY score DESC LIMIT 10'; // クエリ（点が大きい順に 10 件データを取ってくる）
    console.log('query: ' + q);   // これから実行する SQL 文をデバッグ出力する
    pool.query(q, (err, result) => {    // クエリを発行する
        if (err) {  // エラーの時
            console.log(err.stack); // 標準出力にスタックトレースを出力する
        } else {    // 正常に結果が取得できた時
            res.json(result.rows);  // ランキングを json で返す
        }
    });
});

// POST リクエストを受け取った時の処理（データベースにスコア等を追加する）
router.post('/', function (req, res) {
    const name = req.body['name'];    // POST されてきたデータを取り出す
    const score = req.body['score'];    // POST されてきたデータを取り出す
    const insertSql = `INSERT INTO ranking (name, score, timestamp) VALUES('${name}', ${score}, now())`;   // SQL 文を作る
    console.log('execute: ' + insertSql);   // これから実行する SQL 文をデバッグ出力する

    // SQL 文を実行する
    pool.query(insertSql, (err, result) => {
        if (err) {  // エラーの時
            console.log(err.stack);
        } else {    // 正常に実行できた時
            res.status(200).end();
        }
    });
});

module.exports = router;