﻿/*
 * ゲームを制御するための API
 * ルームID、プレイヤーID、盤の位置を渡すと、その位置に石を置く
 */

'use strict';
var express = require('express');
var router = express.Router();

// クラスを使うための宣言
const classes = require('../classes');

// GET リクエストを受け取った時の処理
router.get('/', function (req, res) {
    res.json(global.states);    // ステートの情報をすべて返す（本来こういう機能はつけない）
});

// POST リクエストを受け取った時の処理
router.post('/', function (req, res) {
    // POST されてきたデータを取り出す
    const roomId = req.body['roomId'];
    const playerId = req.body['playerId'];
    const x = Number(req.body['x']);    // 盤の位置の指定 (0~2)
    const y = Number(req.body['y']);    // 盤の位置の指定 (0~2)
    console.log('roomId playerId x y : ', roomId, playerId, x, y);

    var state;
    states = global.states; // グローバル変数から取ってくる
    // 自分のゲームを探す
    for (var i = 0; i < states.length; i++) {
        //console.log('i(counter) roomId : ',  i, states[i].roomId);
        if (states[i].roomId == roomId) {
            console.log('found my state.');
            state = states[i];  // 自分のゲームを見つけた
            break;
        }
    }

    state.board.place(x, y, playerId);   　// 石を置く
    state.switchTurn();   // ターン交代
    console.log('next turn: ', state.turn);
    res.json(state);    // 自分のゲームステートを返す
});

module.exports = router;