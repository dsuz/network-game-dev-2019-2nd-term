﻿/*
 * ゲームを制御するための API
 * ルームID、プレイヤーID、盤の位置を渡すと、その位置に石を置く
 */

'use strict';
var express = require('express');
var router = express.Router();

// クラスを使うための宣言
const classes = require('../classes');

// GET リクエストを受け取った時の処理
router.get('/', function (req, res) {
    res.json(global.states);    // ステートの情報をすべて返す（本来こういう機能はつけない）
});

// POST リクエストを受け取った時の処理
router.post('/', function (req, res) {
    // POST されてきたデータを取り出す
    const roomId = req.body['roomId'];
    const playerId = req.body['playerId'];
    const x = Number(req.body['x']);    // 盤の位置の指定 (0~2) - 指定しない場合は状態のみ取得する
    const y = Number(req.body['y']);    // 盤の位置の指定 (0~2) - 指定しない場合は状態のみ取得する
    console.log('roomId playerId x y : ', roomId, playerId, x, y);

    var state;
    states = global.states; // グローバル変数から取ってくる
    // 自分のゲームを探す
    for (var i = 0; i < states.length; i++) {
        if (states[i].roomId == roomId) {
            console.log('found my state.');
            state = states[i];  // 自分のゲームを見つけた
            break;
        }
    }

    if (Number.isNaN(x) || Number.isNaN(y)) {
        console.log('x or y is Nan. return state.');
    } else {
        state.board.place(x, y, playerId);   　// 石を置く
        // ゲームが終了しているか確認する
        if (CheckGameEnds(state)) {
            state._turn = "";   // ゲームが終了していたら turn は空にする
        } else {
            state.switchTurn();   // ターン交代
        }
        console.log('next turn: ', state.turn);
    }
    res.json(state);    // 自分のゲームステートを返す
});

module.exports = router;

/**
 * ゲームが終了しているか判定する。
 * 勝敗判定はしていない。全てのマス (cell) が埋まっていたらゲーム終了とする。
 * @param {any} state State クラスのインスタンスを渡す
 * @returns {boolean} 終了していれば true
 */
function CheckGameEnds(state) {
    var cells = state._board.cells;
    var isGameEnds = true;
    for (var i = 0; i < cells.length; i++) {
        if (cells[i].length < 1) {
            isGameEnds = false;
            break;
        }
    }
    return isGameEnds;
}