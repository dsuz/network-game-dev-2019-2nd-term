﻿/*
 * 部屋を制御するための API
 * プレイヤーが（一人だけ）いる部屋があったらその部屋に入室し、ゲームを開始する
 * そのような部屋が見つからない場合は新しく部屋を作り、自分が入室する
 */
'use strict';
var express = require('express');
var router = express.Router();

// クラスを使うための宣言
const classes = require('../classes');

// GET リクエストを受け取った時の処理
router.get('/', function (req, res) {
    res.json(global.rooms);    // 現在の部屋の状況を返す
});

// POST リクエストを受け取った時の処理
router.post('/', function (req, res) {
    const playerId = req.body['playerId'];    // POST されてきたデータを取り出す
    console.log('connected. playerID', playerId);

    // 一人だけいる部屋を探す
    var rooms = global.rooms; // グローバル変数を参照する
    var maxRoomId = 0;  // 新しく部屋を作らなければいけない時のために最大の部屋番号を調べる
    for (var i = 0; i < rooms.length; i++) {
        maxRoomId = Math.max(rooms[i].roomId, maxRoomId);
        if (rooms[i].players.length == 1) { // 一人しかいない場合
            console.log('join into roomId: ', rooms[i].roomId);
            rooms[i].addPlayer(playerId);   // join する
            var state = new classes.State(rooms[i]);    // ゲーム開始/ステートを作る。参照したクラスはこのように使う
            global.states.push(state);
            console.log('game start. turn: ', state.turn);
            res.json(rooms[i]); // join した部屋の状態を返す
            return;
        }
    }

    // 一人だけいる部屋が見つからなかったら新しく作る
    console.log('not found good room. create new room.');
    const newRoom = new classes.Room(maxRoomId + 1, playerId);  // 参照したクラスはこのように使う。RoomID が max+1 だといつかオーバーフローするのでよくない。
    console.log('created new room. roomId: ', newRoom.roomId);
    global.rooms.push(newRoom); // グローバル変数に追加する
    res.json(newRoom);  // 新しく作った部屋の状態を返す
});

module.exports = router;