﻿/*
 * クラス定義
 */

// 部屋情報
class Room {
    constructor(roomId, playerId) {
        this.roomId = roomId;
        this._players = [playerId];
    }

    get players() {
        return this._players;
    }

    addPlayer(playerId) {
        this._players.push(playerId);
    }
}

module.exports.Room = Room; // こうすることで外部から使えるようになる

// 盤情報
class Board {
    constructor() {
        this.cells = ['', '', '', '', '', '', '', '', ''];  // JsonUtility が多次元配列をサポートしていないので変更した
    }

    place(x, y, mark) {
        this.cells[x + 3 * y] = mark;   // JsonUtility が多次元配列をサポートしていないので変更した
    }
}

module.exports.Board = Board; // こうすることで外部から使えるようになる

// ゲームステート（ゲーム状態）
class State {
    constructor(room) {
        this.room = room;
        this._turn = room.players[0];   // 部屋を作った人が先攻
        this._board = new Board();
        this.winner = "";   // 勝者
    }

    get turn() {
        return this._turn;
    }

    get board() {
        return this._board;
    }

    get roomId() {
        return this.room.roomId;
    }

    get players() {
        return this.players;
    }

    // ターンを切り替える
    switchTurn() {
        if (this._turn === this.room.players[0]) {
            this._turn = this.room.players[1];
        } else {
            this._turn = this.room.players[0];
        }
    }
}

module.exports.State = State; // こうすることで外部から使えるようになる